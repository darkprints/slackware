Set of converted themes from terminal.sexy project

https://github.com/stayradiated/terminal.sexy
