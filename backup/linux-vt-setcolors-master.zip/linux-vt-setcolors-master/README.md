## Linux Virtual Terminal setcolors utility

This little utility can be used to change the default color palette of the Linux
VT101 virtual console. The program accepts a configuration file containing the
colors in hexadecimal form to use.
