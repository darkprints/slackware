#include <cmTest.h>

int main(void) {
  return doStuff();
}
