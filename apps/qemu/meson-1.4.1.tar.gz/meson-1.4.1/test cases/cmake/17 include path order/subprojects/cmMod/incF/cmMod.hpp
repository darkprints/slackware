// cmMod.hpp (F)
#pragma once

#error "cmMod.hpp in incF must not be included"
