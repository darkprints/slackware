// cmMod.hpp (I)
#pragma once

#error "cmMod.hpp in incI must not be included"
