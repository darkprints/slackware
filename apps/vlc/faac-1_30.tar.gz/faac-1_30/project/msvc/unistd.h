#pragma once

#include <io.h>

#define W_OK    2

#define access _access
